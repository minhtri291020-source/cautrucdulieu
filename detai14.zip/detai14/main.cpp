#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <utility>
using namespace std;
const int M = 100003;


struct Node {
    string key;
    int count;
    Node* next;
};

Node* table[M] = {nullptr};
Node* dictionaryTable[M] = {nullptr};


int hashWord(string s) {
    unsigned long long sum = 0;

    for (int i = 0; i < s.length(); i++) {
        sum += (unsigned char)s[i];
    }

    return (int)(sum % M);
}


int hashHorner(string s) {
    unsigned long long h = 0;

    for (int i = 0; i < s.length(); i++) {
        h = (h * 31 + (int)s[i]) % M;
    }

    return (int)h;
}

int hashDJB2(string s) {
    unsigned long long h = 5381;

    for (int i = 0; i < s.length(); i++) {
        h = (h * 33 + (int)s[i]) % M;
    }

    return (int)h;
}

void evaluateHash(vector<string> words, int type) {
    vector<int> bucket(M, 0);

    for (int i = 0; i < words.size(); i++) {
        int index;

        if (type == 1) {
            index = hashWord(words[i]);
        }
        else if (type == 2) {
            index = hashHorner(words[i]);
        }
        else {
            index = hashDJB2(words[i]);
        }

        
if (index >= 0 && index < M) {
    bucket[index]++;
}
else {
    cout << "Chi so bam khong hop le: "
         << index << endl;
}

    }

    int collisions = 0;
    int longestChain = 0;

    for (int i = 0; i < M; i++) {
        if (bucket[i] > 0) {
            collisions += bucket[i] - 1;
        }

        if (bucket[i] > longestChain) {
            longestChain = bucket[i];
        }
    }

    cout << "So va cham: " << collisions << endl;
    cout << "Chuoi dai nhat: " << longestChain << endl;
}
vector<pair<string, int>> getWordList();
void compareHashFunctions() {
    vector<pair<string, int>> wordList = getWordList();

    vector<string> words;

    for (int i = 0; i < wordList.size(); i++) {
        words.push_back(wordList[i].first);
    }

    cout << "\n===== SO SANH 3 HAM BAM =====" << endl;

    cout << "\n1. SUM ASCII" << endl;
    evaluateHash(words, 1);

    cout << "\n2. HORNER" << endl;
    evaluateHash(words, 2);

    cout << "\n3. DJB2" << endl;
    evaluateHash(words, 3);
}

Node* findWord(string word) {
    int index = hashWord(word);

    Node* p = table[index];

    while (p != nullptr) {
        if (p->key == word) {
            return p;
        }

        p = p->next;
    }

    return nullptr;
}

int getFrequency(string word) {
    Node* p = findWord(word);

    if (p != nullptr) {
        return p->count;
    }

    return 0;
}
vector<string> suggestions;
void sortSuggestions() {
    for (int i = 0; i < suggestions.size(); i++) {
        int maxIndex = i;

        for (int j = i + 1; j < suggestions.size(); j++) {
            if (getFrequency(suggestions[j]) >
                getFrequency(suggestions[maxIndex])) {
                maxIndex = j;
            }
        }

        swap(suggestions[i], suggestions[maxIndex]);
    }
}

void insertDictionary(string word) {
    int index = hashWord(word);

    Node* p = new Node;
    p->key = word;
    p->count = 0;

    p->next = dictionaryTable[index];
    dictionaryTable[index] = p;
}

void readDictionary(string filename) {
    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Khong mo duoc dictionary!" << endl;
        return;
    }

    string word;

    while (file >> word) {
        insertDictionary(word);
    }

    file.close();
}

bool checkSpelling(string word) {
    int index = hashWord(word);

    Node* p = dictionaryTable[index];

    while (p != nullptr) {
        if (p->key == word) {
            return true;
        }

        p = p->next;
    }

    return false;
}



void addSuggestion(string word) {
    for (int i = 0; i < suggestions.size(); i++) {
        if (suggestions[i] == word) {
            return;
        }
    }

    suggestions.push_back(word);
}

void suggestInsert(string word) {
   
    for (int i = 0; i <= word.length(); i++) {
        for (char c = 'a'; c <= 'z'; c++) {
            string candidate = word;

            candidate.insert(i, 1, c);

            if (checkSpelling(candidate)) {
    addSuggestion(candidate);
}
        }
    }
}

void suggestDelete(string word) {
    
    for (int i = 0; i < word.length(); i++) {
        string candidate = word;

        candidate.erase(i, 1);

       if (checkSpelling(candidate)) {
    addSuggestion(candidate);
}
    }
}

void suggestReplace(string word) {
   
    for (int i = 0; i < word.length(); i++) {
        for (char c = 'a'; c <= 'z'; c++) {
            string candidate = word;

            if (candidate[i] == c) {
                continue;
            }

            candidate[i] = c;

            if (checkSpelling(candidate)) {
    addSuggestion(candidate);
}
        }
    }
}

void suggestSwap(string word) {
   
    for (int i = 0; i + 1 < word.length(); i++) {
        string candidate = word;

        swap(candidate[i], candidate[i + 1]);

        if (checkSpelling(candidate)) {
    addSuggestion(candidate);
}
    }
}


void suggestSpelling(string word) {
    suggestions.clear();

    cout << "====================" << endl;
    cout << "Goi y cho tu: " << word << endl;

    suggestInsert(word);
    suggestDelete(word);
    suggestReplace(word);
    suggestSwap(word);

    sortSuggestions();

    if (suggestions.empty()) {
        cout << "Khong tim thay goi y!" << endl;
    }
    else {
        for (int i = 0; i < suggestions.size(); i++) {
            cout << "  -> " << suggestions[i]
                 << " (" << getFrequency(suggestions[i])
                 << " lan)" << endl;
        }
    }

    cout << "====================" << endl;
}



void spellCheckBook(string filename) {
    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Khong mo duoc file!" << endl;
        return;
    }

    string line;
    int lineNumber = 0;

    cout << "CAC TU CHUA DUOC NHAN DIEN" << endl;


while (getline(file, line)) {
    lineNumber++;
    string word = "";

    for (int i = 0; i < line.length(); i++) {
        char c = line[i];

        if (c >= 'A' && c <= 'Z') {
            c = c + 32;
        }

        if (c >= 'a' && c <= 'z') {
            word += c;
        }
        else {
            if (word != "") {
                if (!checkSpelling(word)) {
                    cout << "Dong " << lineNumber
                         << ": " << word << endl;

                    suggestSpelling(word);
                }

                word = "";
            }
        }
    }

    if (word != "") {
        if (!checkSpelling(word)) {
            cout << "Dong " << lineNumber
                 << ": " << word << endl;

            suggestSpelling(word);
        }
    }
}


    file.close();
}

void printDictionary() {
    for (int i = 0; i < M; i++) {
        cout << "dictionaryTable[" << i << "]: ";

        Node* p = dictionaryTable[i];

        while (p != nullptr) {
            cout << p->key << " -> ";
            p = p->next;
        }

        cout << "NULL" << endl;
    }
}



void insertWord(string word) {
    Node* found = findWord(word);

    if (found != nullptr) {
        found->count++;
        return;
    }

    int index = hashWord(word);

    Node* p = new Node;
    p->key = word;
    p->count = 1;

    p->next = table[index];
    table[index] = p;
}


void printTable() {
    for (int i = 0; i < M; i++) {
        cout << "table[" << i << "]: ";

        Node* p = table[i];

        while (p != nullptr) {
            cout << p->key << "(" << p->count << ") -> ";
            p = p->next;
        }

        cout << "NULL" << endl;
    }
}


void statistics() {
    int totalWords = 0;
    int distinctWords = 0;

    for (int i = 0; i < M; i++) {
        Node* p = table[i];

        while (p != nullptr) {
            totalWords += p->count;
            distinctWords++;

            p = p->next;
        }
    }

    cout << "Tong so tu: " << totalWords << endl;
    cout << "So tu phan biet: " << distinctWords << endl;
}

vector<pair<string, int>> getWordList() {
    vector<pair<string, int>> wordList;

    for (int i = 0; i < M; i++) {
        Node* p = table[i];

        while (p != nullptr) {
            wordList.push_back({p->key, p->count});

            p = p->next;
        }
    }

    return wordList;
}

void selectionSort(vector<pair<string, int>>& wordList) {
    int n = wordList.size();

    for (int i = 0; i < n - 1; i++) {
        int maxIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (wordList[j].second > wordList[maxIndex].second) {
                maxIndex = j;
            }
        }

        if (maxIndex != i) {
            swap(wordList[i], wordList[maxIndex]);
        }
    }
}

bool isStopword(string word) {
    string stopwords[] = {
        "the", "a", "an", "is", "are",
        "and", "or", "of", "to", "in",
        "on", "at", "for", "with", "by",
        "this", "that", "it", "be", "as"
    };

    int n = 20;

    for (int i = 0; i < n; i++) {
        if (word == stopwords[i]) {
            return true;
        }
    }

    return false;
}

void printTop20(vector<pair<string, int>>& wordList) {
    int count = 0;

    cout << "\nTOP 20 TU PHO BIEN NHAT" << endl;

    for (int i = 0; i < wordList.size(); i++) {
        string word = wordList[i].first;
        int frequency = wordList[i].second;

        if (isStopword(word)) {
            continue;
        }

        count++;

        cout << count << ". "
             << word << ": "
             << frequency << endl;

        if (count == 20) {
            break;
        }
    }
}

void readBook(string filename) {
    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Khong mo duoc file!" << endl;
        return;
    }

    string line;

    while (getline(file, line)) {
        string word = "";

        for (int i = 0; i < line.length(); i++) {
            char c = line[i];

            if (c >= 'A' && c <= 'Z') {
                c = c + 32;
            }

            if (c >= 'a' && c <= 'z') {
                word += c;
            }
            else {
                if (word != "") {
                    insertWord(word);
                    word = "";
                }
            }
        }

        if (word != "") {
            insertWord(word);
        }
    }

    file.close();
}

int main() {
    readDictionary("dictionary_large.txt");
    readBook("book_large.txt");

    int choice;

    do {
        cout << "\n========== DE TAI 14 ==========" << endl;
        cout << "KIEM TRA CHINH TA VA THONG KE VAN BAN" << endl;
        cout << "------------------------------------" << endl;
        cout << "1. Thong ke van ban" << endl;
        cout << "2. Top 20 tu xuat hien nhieu nhat" << endl;
        cout << "3. Kiem tra chinh ta" << endl;
        cout << "4. So sanh 3 ham bam" << endl;
        cout << "0. Thoat" << endl;
        cout << "------------------------------------" << endl;
        cout << "Nhap lua chon: ";

        if (!(cin >> choice)) {
            cout << "Lua chon khong hop le!" << endl;
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (choice) {
            case 1:
                cout << "\n===== THONG KE VAN BAN =====" << endl;
                statistics();
                break;

            case 2: {
                cout << "\n===== TOP 20 TU =====" << endl;

                vector<pair<string, int>> wordList = getWordList();
                selectionSort(wordList);
                printTop20(wordList);

                break;
            }

            case 3:
                cout << "\n===== KIEM TRA CHINH TA =====" << endl;
                spellCheckBook("book.txt");
                break;

            case 4:
                compareHashFunctions();
                break;

            case 0:
                cout << "Tam biet!" << endl;
                break;

            default:
                cout << "Lua chon khong hop le!" << endl;
        }

    } while (choice != 0);

    return 0;
}


